"""
Snubber LangChain Adapter
"""
