"""
Snubber CrewAI Adapter
"""
