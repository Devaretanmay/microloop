"""
Snubber LangGraph Adapter
"""
