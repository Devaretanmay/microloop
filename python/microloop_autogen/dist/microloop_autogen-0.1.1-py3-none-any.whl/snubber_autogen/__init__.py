"""
Snubber AutoGen Adapter
"""
